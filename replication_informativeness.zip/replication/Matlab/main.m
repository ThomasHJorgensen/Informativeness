% this script estimates the joint retirement model and then reports the
% estimation output.
% The estimation procedure takes some time!

run_estimate
run_post_estimation